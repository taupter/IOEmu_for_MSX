# MAIN-ROM 統合ツール

[English README](README.md)

`musx_mainrom_merge.exe` を起動し、U2 PIC18用firmware（HEXファイル）と利用者が用意した32,768バイトのMSX1用MAIN-ROM（バイナリファイル）を選択し、MAIN-ROM統合版firmware（HEXファイル）の保存先を指定して **MAIN-ROMを挿入** をクリックします。

MAIN-ROMデータは32,768バイトです。MAIN-ROMデータは配布物に含まれないため、利用者が正当に使用できるROMデータを用意してください。詳細は `LICENSE.txt` と `THIRD_PARTY_LICENSES.txt` を参照してください。
