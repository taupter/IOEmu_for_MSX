# MAIN-ROM Merge Tool

[日本語版 README](README_ja.md)

Start `musx_mainrom_merge.exe`, select the U2 PIC18 firmware (HEX file) and your 32,768-byte MSX1 MAIN-ROM (binary file), specify the output path for the firmware with the MAIN-ROM integrated, and click **Insert MAIN-ROM**.

The MAIN-ROM must be exactly 32,768 bytes. MAIN-ROM data is not included in this distribution, so you must provide ROM data that you are legally entitled to use. See `LICENSE.txt` and `THIRD_PARTY_LICENSES.txt` for details.
